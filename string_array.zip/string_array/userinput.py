input=input("enter a string : ")

def conversion(input):
    uppercase = input.upper()
    lowercase = input.lower()
    print("upper case : ", uppercase)
    print("lower case : ", lowercase)

conversion(input)