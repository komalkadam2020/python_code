def odd_value_string(str):
    result = ""
    for i in range(len(str)):
        if i % 2 ==0:
            result = result + str[i]
    return result

print(odd_value_string("abcabccde"))
print(odd_value_string("123456789"))