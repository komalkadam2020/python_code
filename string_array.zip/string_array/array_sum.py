num = list(map(int, input("enter array :").split()))
a = num[::-1]
for i in a:
    print(i, end=" ")
result = sum(num)
print("Sum of list items", result)

print(max(num))