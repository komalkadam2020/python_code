def string_both_end(str):
    if len(str) < 2:
        return ' '
    return str[0:2] + str[-2:]
print(string_both_end('hihowru'))
print(string_both_end("hi"))
print(string_both_end("h"))