for x in range(0,5):
    if x==3:
        break
    print(x)