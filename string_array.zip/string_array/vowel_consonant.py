word = input("Enter a text : ")

vowel = 0
cons = 0

for i in range(len(word)):
    if word[i] in ['a', 'i', 'e', 'o', 'u']:
        vowel = vowel + 1
        print(word[i], end=' ')
    else:
        cons = cons + 1

print("\n Total vowels are: ", vowel)
print("Total consonant are: ", cons)

