arr = list(map(int, input("enter array element :").split()))
l = int(input("Enter length of array : "))
a = arr[::-1]
for i in a:
    print(i, end=" ")