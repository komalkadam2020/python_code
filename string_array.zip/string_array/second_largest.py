def findLargest(arr):
    '''
    secondLargest = 0
    largest = min(arr)   #4
    print(len(arr))
    print(largest)

    for i in range(len(arr)):
        if arr[i] > largest:
            secondLargest = largest
            largest = arr[i]
        else:
            secondLargest = max(secondLargest, arr[i])

    # Returning second largest element
    return secondLargest
    '''

    new_list=set(arr)
    new_list.remove(max(new_list))
   # return max(new_list)
    return sorted(arr)[-2]

# Calling above method over this array set
print(findLargest([10, 20, 4, 45, 99]))