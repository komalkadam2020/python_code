input1 = input("enter a string ")
res=input1.split(" ")
k=[]
for i in res:
    a=i[::-1]
    k.append(a[0].upper()+a[1:].lower())
print(" ".join(k))