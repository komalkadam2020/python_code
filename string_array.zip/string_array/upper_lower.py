num = input("Enter a string : ")
x = []

for i in range(len(num)):
    if num[i].isupper():
        x.append(num[i].lower())
    elif num[i].islower():
        x.append(num[i].upper())

for i in range(len(x)):
    print(x[i], end='')