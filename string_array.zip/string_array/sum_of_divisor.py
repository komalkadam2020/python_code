def sum_div(number):
    divisor = []
    for i in range(1, number):
        if (number % i)==0:
            divisor.append(i)
    return sum(divisor)

print(sum_div(8))
print(sum_div(12))
