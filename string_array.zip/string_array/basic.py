l = [1, 2, 3, 4, 5]
print(l[-2])

l = [[1,2,3], 4, 'a', True, [],(), ]
print(len(l))
print(type(1.0))

print('lo' in 'hello world')

print([1, 2, 3]+[3, 2, 1])

print('hello world' [::-1])

l1=[1,2,3]
print(l1)

'A' + 'B' if '12'.isdigit() else 'X' + 'Y'

import math
print(abs(math.sqrt(36)))

print(2**(3**2))

x=56.236
print("%.2f"%x)

print((1, 2, 3)+(3, 2, 1))
