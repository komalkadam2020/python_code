##########~reverse_character in the string########333

input1 = input()
res = input1.split(" ")
k = []
for i in res:
    a = i[::-1]
    k.append(a[0].upper() + a[1:].lower())
print(" ".join(k))

#############reverse an array###############3

arr = list(map(int, input("enter array element :").split()))
l = int(input("Enter length of array : "))
a = arr[::-1]
for i in a:
    print(i, end=" ")


#####Sum of divisor  ######33
def sum_div(number):
    divisor = []
    for i in range(1, number):
        if (number % i) == 0:
            divisor.append(i)
    return sum(divisor)

    #####perfect sum ###
    def perfectSum(input1, input2, input3):
        if (input3 == 0):
            return 1
        elif (input3 != 0 and input1 == 0):
            return 0
        elif (input2[input1 - 1] > input3):
            return perfectSum(input1 - 1, input2, input3)
        else:
            return perfectSum(input1 - 1, input2, input3) + perfectSum(input1 - 1, input2, input3 - input2[input1 - 1])


input1 = int(input())
input2 = list(map(int, input().split()))
input3 = int(input())
print(perfectSum(input1, input2, input3))


##### palindrome ###
def palindrome(input1):
    s = input1.lower().split()
    count = 0
    for i in s:
        if i[:] == i[::-1] and len(i) > 1:
            count += 1
    return count


input1 = input()
print(palindrome(input1))


##### David and the training regimen ####3
def davidReigman(input1):
    a = 1
    b = 2
    c = 3
    if input1 == 0:
        return 0
    elif input1 == 1:
        return b
    elif input1 == 2:
        return c
    else:
        for i in range(3, input1):
            d = a + b + c
            a = b
            b = c
            c = d
        return d


input1 = int(input())
print(davidReigman(input1))


#### string wthin string  #3
def String_withString(input1, input2):
    return "yes" if input2 in input1 else "no"


input1 = input()
input2 = input()
print(String_withString(input1, input2))


###### nNth character in decrypted string ###
def stringIndex(input1, input2):
    s = ""
    res = ""
    for i in range(len(input1)):
        if input1[i].isdigit():
            res += s * int(input1[i])
            s = ""
        else:
            s += input1[i]
    if (input2 > len(res)):
        return -1
    return res[input2 - 1]


input1 = input()
input2 = int(input())
print(stringIndex(input1, input2))


#######33 String permutation ####
def String_Permutation(str1, str2):
    count1 = [0] * 256
    count2 = [0] * 256
    for i in str1:
        count1[ord(i)] += 1
    for i in str2:
        count2[ord(i)] += 1
    if len(str1) != len(str2):
        return 0
    for i in range(256):
        if count1[i] != count2[i]:
            return "no"
    return "yes"


str1 = "level"
str2 = "llvee"
print(String_Permutation(str1, str2))


########## Abraham:-###########
def abraham(n):
    for i in range(n):
        if (n >= 2 ** i) and (n < 2 ** (i + 1)):
            return (2 ** i) - 1


########### Adding Number ##############
def adding(n, m, p):
    sum = 0
    total = 0
    for i in range(0, n, 2):
        if (i + 1 < n):
            sum = m[i] + m[i + 1]
            total += sum * p
        sum = 0
    for i in range(n):
        sum += m[i]
    total += sum * p
    return total


############ Adding Marble:-##############
def add_marble(n, arr):
    if arr[n - 1] < 9:
        return n
    else:
        index = n
        while ((index > 0) & (arr[index - 1] == 9)):
            index = index - 1
        return index


########## Alt Tab:-############
def alt_tab(n, k, arr):
    j = 0
    b = [0] * n
    b[j] = arr[k - 1]
    for i in range(n):
        if i != k - 1:
            j += 1
            b[j] = arr[i]
    return b


############ Best Friend ############
def bestfriend(n, str):
    count = 0
    ll = []
    c = -1
    li = []
    for letter in str:
        li.append(letter)
    i = 0
    while i < n:
        if len(ll) == 0:
            if li[i] == '1':
                ll.append(li[i])
                li[i] = 'a'
        if len(ll) == 1:
            if li[i] == '2':
                ll.append(li[i])
                li[i] = 'a'
        if len(ll) == 2:
            if li[i] == '3':
                li[i] = 'a'
                count += 1
                i = c
                ll.clear()
        i += 1
    return count


########## Charles & Necklace:-##########
from itertools import combinations_with_replacement


def necklace(n, lm, hm):
    p = []
    for x in range(lm, hm + 1):
        p.append(x)
    necklace = []
    for i in range(1, n + 1):
        necklace = necklace + list(combinations_with_replacement(p, i))
    return len(necklace)


####### Children Day:-############
def child(arr, k):
    arr.sort(reverse=True)
    index = arr[k - 1]
    return index


###### Coding Marathon:-########
def marathon(arr, n, k):
    sum = 0
    arr.sort()
    arr.reverse()
    for i in range(0, k):
        sum += arr[i]
    return sum


########## Cut and Add(Harry potter) ###########
def harry(str, m, n):
    l = len(str)
    org = str.upper()
    str = str.upper()
    turn = 0
    for i in str:
        str1 = str[-m:]
        str = str.replace(' ', '')[:-m]
        str = str1 + str
        print(str)
        if org != str:
            turn += 1
            str2 = str[-n:]
            str = str.replace(' ', '')[:-n]
            str = str2 + str
            print(str)
            turn += 1
        if org == str:
            break
    print(turn)


######### Credits:-##########
def credit(k, arr1, n, arr2):
    count = 0
    for i in range(n):
        for j in range(k):
            if (arr2[i] >= arr1[j]):
                count += 1
    return count


############ Documents #############
import re


def documents(input1):
    uniqueDates = set()
    s = "[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]"
    dates = re.findall(s, input1)
    for i in dates:
        uniqueDates.add(i.split("-")[-1])
    return len(uniqueDates)


####### Electrostatics:-#########
def electrostatics(n, arr):
    total = 0
    val = 0
    ch = input("Enter charges ")
    print(ch)
    for i in range(n):
        if ch[i] == 'P' and ch[i] == 'p':
            total += arr[i]
        else:
            total -= arr[i]
    val = total * 100
    return abs(val)


############# Energy ############
def energy(input1, input2):
    power = -1
    while input1 != input2:
        power -= 1
        if input1 > input2:
            input1 = input1 // 2
        else:
            input2 = input2 // 2
    return power


########### Fishes ###########
def fishes(ip1, ip2, ip3, ip4):
    barr = []
    for i in range(ip2):
        barr.append(-1)
    for i in range(ip3):
        if ip4[i][0] == 1:
            barr[ip4[i][2] - 1] = ip4[i][1]
        elif ip4[i][0] == 2:
            for j in range(ip2):
                if barr[j] == ip4[i][2]:
                    barr[j] = ip4[i][1]
    c = []
    for i in range(ip2):
        c.append(barr[i])
    return c


########## Greedy Businessman #####
def greedy(ip1, ip2):
    count = 0
    k = 0
    arr = [0] * (ip1 * 2)
    for i in range(ip1):
        arr[k] = ip2[0][i]
        arr[k + 1] = ip2[1][i]
        k += 2
    for i in range(0, k - 1):
        if (arr[i] >= arr[i + 1]):
            count += 1
    if (count == 0):
        return ip1
    else:
        return count


ip1 = int(input())
ip2 = []
b = []
for i in range(ip1):
    a = list(map(int, input().split()))
    b.append(a[1])
    ip2.append(a)
print(greedy(ip1, ip2))


############# Great Battle ##########
def battle(n, m, a):
    l = [0] * 1000
    ans = []
    for i in range(1000):
        l[i] = 1
    for i in range(m):
        l[a[i]] = 0
    for i in range(1, n + 1):
        if (l[i] == 1):
            ans.append(i)
        else:
            if (2 * i <= n):
                l[2 * i] = 0
            if (2 * i + 1 <= n):
                l[2 * i + 1] = 0
    return ans


n = int(input())
m = int(input())
a = list(map(int, input().split()))
print(battle(n, m, a))


############## Halindrome #############
def halindrome(n, arr):
    arr1 = [i[::-1] for i in arr]
    count = 0
    for i in range(len(arr)):
        if arr[i] == arr1[i]:
            count += 1
    return count


n = int(input())
arr = input().split()
print(halindrome(n, arr))


######## Harold & Homework:-###########
def harold(n, arr1, arr2):
    sum = 0
    for i in range(n):
        for j in range(i + 1, n):
            if arr2[i] == arr2[j]:
                if arr1[i] > arr1[j]:
                    arr1[j] = 0
                else:
                    arr1[i] = 0
    for i in range(n):
        sum += arr1[i]
    return sum


############ Jim's OS #############
def jims_OS(n, a1, a2):
    sum = 0
    for i in range(n):
        for j in range(i + 1, n):
            if a1[i] > a1[j]:
                temp = a1[i]
                a1[i] = a1[j]
                a1[j] = temp

                temp1 = a2[i]
                a2[i] = a2[j]
                a2[j] = temp1
    sum = a1[0] + a2[0]
    for i in range(1, n):
        if sum > a1[i]:
            sum += a2[i]
        else:
            m = a1[i] - sum
            sum += a2[i] + m
    return sum


########### LCS with vowels ###########
def LCS(ip1, ip2):
    l1 = [0] * 5
    l2 = [0] * 5
    count = 0
    ch = ['a', 'e', 'i', 'o', 'u']
    for i in range(0, len(ip1)):
        for j in range(0, 5):
            if ip1[i] == ch[j]:
                l1[j] += 1
    for i in range(0, len(ip2)):
        for j in range(0, 5):
            if ip2[i] == ch[j]:
                l2[j] += 1
    for i in range(0, 5):
        count += min(l1[i], l2[i])
    return count


####### Largest Prime Divisor:-##########
def prime(n):
    count = 0
    for i in range(2, n):
        if (n % i == 0):
            count += 1
    if (count == 0):
        return 1


def largest_prime(num):
    max = -1
    for i in range(2, num):
        if (num % i == 0):
            if (prime(i) == 1):
                max = i
    return max


######### Love Letter ###########
def love_letter(str, k):
    strRotate = str.split()
    for i in range(k):
        for j in range(len(strRotate)):
            strRotate[j] = strRotate[j][:1] + strRotate[j][0]
        count = 0
        for k in range(len(strRotate)):
            if strRotate[k] in str:
                count += 1
    print(count)


######## Mars Stone:-#############
def mars_stone(arr1, arr2, n, m):
    c = 0
    sum = 0
    for i in range(n):
        for j in range(m):
            if (arr1[i] == arr2[j]):
                arr1[i] = 0
    for i in range(n):
        if (arr1[i] != 0):
            sum = sum + arr1[i]
            if (sum <= n):
                c += 1
    return c


############ Machine #############
def machine(ip1, ip2):
    sum = 0
    pro = 1
    temp = 0
    a = 0
    temp = ip2 - ((ip1 * 2) - 1) + 1
    a = temp
    for i in range(1, a + 1):
        sum += (temp) * i
        temp -= 1
    while ip1 != 0:
        pro *= ip1
        ip1 -= 1
    return (sum * pro)


ip1 = int(input())
ip2 = int(input())
print(machine(ip1, ip2))


####### Missing Marble:-###########
def missing_marble(n, arr):
    num = arr[0] + arr[n - 1]
    j = n - 1
    ans = 0
    for i in range(n):
        if (arr[i] + arr[j]) != num:
            ans = num - arr[i]
            elif i == j:
            ans = num - arr[i]
    j = j - 1


return ans


####### Morse Code:-############
def morse(n, b):
    y = len(b)
    c = 0
    i = 0
    while n != 0:
        if b[i][0] == "." and b[i][len(b[i]) - 1] == "-":
            d = b[i].count('.')
            e = b[i].count('-')
            if d == e:
                c += 1
        n -= 1
        i += 1
    return c


########## Mr mayer exam:-###############
def myer(n, arr):
    sum = 0
    count = 0
    arr.sort()
    for i in range(n):
        j = i - 1
        while (j >= 0):
            if arr[i] == arr[j]:
                count += 1
                arr[i] = arr[i - 1] + 1
            j -= 1
    for i in range(n):
        # arr
        sum += arr[i]
    return sum


############# Parents ###############
def parents(ip1, ip2, ip3):
    c = 0
    i = 0
    while i < ip1:
        if ip3.count(i) >= ip2:
            c += 1
        i += 1
    if c == 0:
        return -1
    else:
        return c


######## Placement season begin:-############
def placement(num, arr1):
    c = 0
    arr2 = []
    for i in range(num):
        for j in range(i + 1):
            if arr1[j] > arr1[i]:
                c += 1
            else:
                pass
        arr2.append(c)
        c = 0
    return arr2


########## Picnic #################
def picnics(n, arr):
    count = 0
    ll = []
    i = 0
    while i < n:
        if arr[i] in ll:
            count += 1
            ll.clear()
        elif arr[i] not in ll:
            ll.append(arr[i])
        i += 1
    return count


n = int(input())
arr = list(map(int, input().split()))[:n]
print(picnics(n, arr))


########### Planting Tree ##########
def planting_tree(n, k):
    a = 2
    res = (a + n) % k
    return res
    OR


q = []
q.append(2)
for i in range(n):
    v = q.pop()
    for j in range(0, (v + 1) % k, 1):
        q.append(j)
return len(q)


########### Reducing dishes:-##########
def dishes(i1, i2):
    c = 2
    s = i2[0]
    for i in range(i1):
        if i2[i] >= 0:
            s += i2[i] * c
            c += 1
    return s


############ Race #############
def race(ip1, ip2):
    s = []
    for i in ip2:
        t = [] + [0] * (i[0] - 1)
        for j in range(i[0], i[1]):
            t = t + [1]
        s = s + [t + [0] * (max(b) - len(t))]
    x = []
    for i in range(max(b)):
        c = 0
        for j in range(len(s)):
            if s[j][i] == 1:
                c += 1
        x.append(c)
    return max(x)


ip1 = int(input())
ip2 = []
b = []
for i in range(ip1):
    a = list(map(int, input().split()))
    b.append(a[1])
    ip2.append(a)
print(race(ip1, ip2))


############ Representative ##########
def representative(n, arr, k):
    list = []
    temp = []
    ditt = []
    d = 9999
    arr.sort(reverse=True)
    if k == 1:
        return max(arr)
    else:
        for i in range(n - 1):
            ditt = arr[i] - arr[i + 1]
            if ditt < d:
                c = i
                d = ditt
        for i in range(k):
            temp.append(arr[c])
            c += 1
        temp.sort()
        return temp


########## Sapna problem solving #########
def sapna(n, str):
    t = 240 - str
    c = 0
    q = 0
    for i in range(n):
        q += 5 * i
        if q <= t:
            c += 1
    return c


n, str = list(int(i) for i in input().split())
print(sapna(n, str))


######### Serena Flower:-###########
def serena(n, k, arr):
    count = 0
    i = 1
    j = 0
    for i in range(k):
        for j in range(i):
            if (arr[i] == arr[j]):
                break
            j += 1
        if (i == j):
            count += 1
        i += 1
    return count


########## Sibling:-##############
def identify_siblings(n, arr, x):
    index = arr.index(x)
    level = 0
    start_index = level
    number_of_nodes = 0
    while start_index < n:
        end_index = pow(2, level) + start_index
        if x in arr[start_index:end_index]:
            break
        level += 1
        start_index = (2 * start_index) + 1
    final_array = arr[start_index:end_index]
    final_array.remove(x)
    return set(final_array) if final_array else {-1}


########## Shunting Yard Problem ##########
def shunting_yard(str):
    return int(eval(str))
    str = input()


print(shunting_yard(str))


######### Social Network ############
def prime(num):
    if num > 1:
        for i in range(2, num):
            if num % i == 0:
                return 0
    return 1


def social(n):
    count = 1
    for i in range(2, n + 2):
        if prime(i) == 1 and i * 2 > n + 1:
            count += 1
    if n <= 2:
        count -= 1
    return count


n = int(input())
print(social(n))


########## Special Unit ############
def special_unit(n, a):
    a.sort()
    count = 0
    i = 0
    while (i < n - 1):
        if (a[i + 1] <= a[i]):
            a[i + 1] = a[i + 1] + 1
            count += 1
            i = i - 1
        i += 1
    return count


########### Stick Game ################
def stick_game(n, arr):
    sum = 0
    for i in range(0, n, 2):
        if arr[i] > arr[i + 1]:
            sum += arr[i + 1]
        else:
            sum += arr[i]
    return sum


########### Stocks ############
def stocks(n, arr):
    sum = 0
    for i in range(n):
        if arr[i] < 0:
            sum += arr[i]
        else:
            break
    return sum
    OR


def stocks(n, arr):
    price = 0
    best_price = 0
    for i in range(n):
        price += arr[i]
        if best_price > price:
            best_price = price
    return best_price


######### Street Light #############
def street_light(n, arr1):
    d = 0
    c = 0
    for i in range(n):
        arr2 = []
        x, y = map(int, input().split())
        arr2.append(x)
        arr2.append(y)
        arr1.append(arr2)
    for j in range(n):
        if arr1[j][0] < d:
            s = d
        else:
            s = arr1[j][0]
        e = arr1[j][1]
        c += e - s
        d = arr1[j][1]
    return c

    OR


def street_light(n, arr1):
    sum1 = 0
    sum2 = 0
    l = len(arr1) - 1
    for i in arr1:
        sum1 = sum1 + i[1] - i[0]
    for j in range(0, l):
        if arr1[j + 1][0] < arr1[j][1]:
            sum2 = sum2 + (arr1[j][1] - arr1[j + 1][0])
    return (sum1 - sum2)


n = int(input())
arr1 = []
for i in range(n):
    arr2 = []
    x, y = map(int, input().split())
    arr2.append(x)
    arr2.append(y)
    arr1.append(arr2)
print(street_light(n, arr1))


########## String Rotation ############
def string_rotate(s1, s2):
    numberRotation = 0
    temp = s1
    nomatch = False
    while temp != s2:
        numberRotation += 1
        temp = s1[len(s2) - numberRotation:] + s1[0:len(s1) - numberRotation]
        if numberRotation >= len(s1):
            temp = s2
            nomatch = True
    if nomatch:
        print("No Match")
    else:
        print(str(numberRotation))


########### Subject Marks ############
def subject_marks(n, arr):
    sum = 0
    for i in range(n):
        if arr[i] < arr[i - 1]:
            arr[i] = arr[i - 1] + 1
        sum += arr[i - 1]
    sum += arr[len(arr) - 1]
    return sum


n = int(input())
arr = list(map(int, input().split()))
print(subject_marks(n, arr))


############# University ###########
def university(ip1, ip2, ip3, ip4):
    count = 0
    for i in range(len(ip4)):
        for j in range(len(ip2)):
            if ip4[i] > ip2[j]:
                count += 1
    return count


ip1 = int(input())
ip2 = list(map(int, input().split()))
ip3 = int(input())
ip4 = list(map(int, input().split()))
print(university(ip1, ip2, ip3, ip4))


######### Wedding Game ###########
def wedding(s, y):
    count = 0
    n = 0
    l = len(s)
    for i in range(l):
        n = n * 10 + int(s[i])
        if n <= y:
            x = 1
            continue
        else:
            if x:
                count += 1
                n = int(s[i])
                x = 0
            if n <= y:
                x = 1
            else:
                num = 0
    if x:
        count += 1
    return count


######### X_mus Eve ############
solCount = 0


def collect(remAmount, remHouse, prevAmount):
    global solCount
    if remHouse == 0:
        return
    if remAmount < 0:
        return
    if remAmount == 0:
        solCount += 1
        return
    for i in range(1, prevAmount, 1):
        collect(remAmount - i, remHouse - 1, i)


def solution(amount, house):
    for i in range(0, amount + 1):
        collect(amount - i, house - 1, i)
    return solCount


######### Zombie Apoclypes #########
def zombie_apoclypes(n, arr, k):
    contagious = 1
    zombies = 0
    day = 1
    arr[1] = 0
    while (zombies < n):
        day += 1
        arr[day] = contagious
        zombies += arr[day]
        if (day - k + 1 >= 1):
            contagious += arr[day - k + 1]
    return day


########## Zombies ###############
def gcd(a, b):
    if (a == 0):
        return b
    else:
        return gcd(b % a, a)


def zombies(arr, n):
    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            if (gcd(arr[i], arr[i + 1]) == 1):
                return i
    return -1


##########~reverse_character in the string########333

input1 = input()
res = input1.split(" ")
k = []
for i in res:
    a = i[::-1]
    k.append(a[0].upper() + a[1:].lower())
print(" ".join(k))

#############reverse an array###############3

arr = list(map(int, input("enter array element :").split()))
l = int(input("Enter length of array : "))
a = arr[::-1]
for i in a:
    print(i, end=" ")


#####Sum of divisor  ######33
def sum_div(number):
    divisor = []
    for i in range(1, number):
        if (number % i) == 0:
            divisor.append(i)
    return sum(divisor)

    #####perfect sum ###
    def perfectSum(input1, input2, input3):
        if (input3 == 0):
            return 1
        elif (input3 != 0 and input1 == 0):
            return 0
        elif (input2[input1 - 1] > input3):
            return perfectSum(input1 - 1, input2, input3)
        else:
            return perfectSum(input1 - 1, input2, input3) + perfectSum(input1 - 1, input2, input3 - input2[input1 - 1])


input1 = int(input())
input2 = list(map(int, input().split()))
input3 = int(input())
print(perfectSum(input1, input2, input3))


##### palindrome ###
def palindrome(input1):
    s = input1.lower().split()
    count = 0
    for i in s:
        if i[:] == i[::-1] and len(i) > 1:
            count += 1
    return count


input1 = input()
print(palindrome(input1))


##### David and the training regimen ####3
def davidReigman(input1):
    a = 1
    b = 2
    c = 3
    if input1 == 0:
        return 0
    elif input1 == 1:
        return b
    elif input1 == 2:
        return c
    else:
        for i in range(3, input1):
            d = a + b + c
            a = b
            b = c
            c = d
        return d


input1 = int(input())
print(davidReigman(input1))


#### string wthin string  #3
def String_withString(input1, input2):
    return "yes" if input2 in input1 else "no"


input1 = input()
input2 = input()
print(String_withString(input1, input2))


###### nNth character in decrypted string ###
def stringIndex(input1, input2):
    s = ""
    res = ""
    for i in range(len(input1)):
        if input1[i].isdigit():
            res += s * int(input1[i])
            s = ""
        else:
            s += input1[i]
    if (input2 > len(res)):
        return -1
    return res[input2 - 1]


input1 = input()
input2 = int(input())
print(stringIndex(input1, input2))


#######33 String permutation ####
def String_Permutation(str1, str2):
    count1 = [0] * 256
    count2 = [0] * 256
    for i in str1:
        count1[ord(i)] += 1
    for i in str2:
        count2[ord(i)] += 1
    if len(str1) != len(str2):
        return 0
    for i in range(256):
        if count1[i] != count2[i]:
            return "no"
    return "yes"


str1 = "level"
str2 = "llvee"
print(String_Permutation(str1, str2))


########## Abraham:-###########
def abraham(n):
    for i in range(n):
        if (n >= 2 ** i) and (n < 2 ** (i + 1)):
            return (2 ** i) - 1


########### Adding Number ##############
def adding(n, m, p):
    sum = 0
    total = 0
    for i in range(0, n, 2):
        if (i + 1 < n):
            sum = m[i] + m[i + 1]
            total += sum * p
        sum = 0
    for i in range(n):
        sum += m[i]
    total += sum * p
    return total


############ Adding Marble:-##############
def add_marble(n, arr):
    if arr[n - 1] < 9:
        return n
    else:
        index = n
        while ((index > 0) & (arr[index - 1] == 9)):
            index = index - 1
        return index


########## Alt Tab:-############
def alt_tab(n, k, arr):
    j = 0
    b = [0] * n
    b[j] = arr[k - 1]
    for i in range(n):
        if i != k - 1:
            j += 1
            b[j] = arr[i]
    return b


############ Best Friend ############
def bestfriend(n, str):
    count = 0
    ll = []
    c = -1
    li = []
    for letter in str:
        li.append(letter)
    i = 0
    while i < n:
        if len(ll) == 0:
            if li[i] == '1':
                ll.append(li[i])
                li[i] = 'a'
        if len(ll) == 1:
            if li[i] == '2':
                ll.append(li[i])
                li[i] = 'a'
        if len(ll) == 2:
            if li[i] == '3':
                li[i] = 'a'
                count += 1
                i = c
                ll.clear()
        i += 1
    return count


########## Charles & Necklace:-##########
from itertools import combinations_with_replacement


def necklace(n, lm, hm):
    p = []
    for x in range(lm, hm + 1):
        p.append(x)
    necklace = []
    for i in range(1, n + 1):
        necklace = necklace + list(combinations_with_replacement(p, i))
    return len(necklace)


####### Children Day:-############
def child(arr, k):
    arr.sort(reverse=True)
    index = arr[k - 1]
    return index


###### Coding Marathon:-########
def marathon(arr, n, k):
    sum = 0
    arr.sort()
    arr.reverse()
    for i in range(0, k):
        sum += arr[i]
    return sum


########## Cut and Add(Harry potter) ###########
def harry(str, m, n):
    l = len(str)
    org = str.upper()
    str = str.upper()
    turn = 0
    for i in str:
        str1 = str[-m:]
        str = str.replace(' ', '')[:-m]
        str = str1 + str
        print(str)
        if org != str:
            turn += 1
            str2 = str[-n:]
            str = str.replace(' ', '')[:-n]
            str = str2 + str
            print(str)
            turn += 1
        if org == str:
            break
    print(turn)


######### Credits:-##########
def credit(k, arr1, n, arr2):
    count = 0
    for i in range(n):
        for j in range(k):
            if (arr2[i] >= arr1[j]):
                count += 1
    return count


############ Documents #############
import re


def documents(input1):
    uniqueDates = set()
    s = "[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]"
    dates = re.findall(s, input1)
    for i in dates:
        uniqueDates.add(i.split("-")[-1])
    return len(uniqueDates)


####### Electrostatics:-#########
def electrostatics(n, arr):
    total = 0
    val = 0
    ch = input("Enter charges ")
    print(ch)
    for i in range(n):
        if ch[i] == 'P' and ch[i] == 'p':
            total += arr[i]
        else:
            total -= arr[i]
    val = total * 100
    return abs(val)


############# Energy ############
def energy(input1, input2):
    power = -1
    while input1 != input2:
        power -= 1
        if input1 > input2:
            input1 = input1 // 2
        else:
            input2 = input2 // 2
    return power


########### Fishes ###########
def fishes(ip1, ip2, ip3, ip4):
    barr = []
    for i in range(ip2):
        barr.append(-1)
    for i in range(ip3):
        if ip4[i][0] == 1:
            barr[ip4[i][2] - 1] = ip4[i][1]
        elif ip4[i][0] == 2:
            for j in range(ip2):
                if barr[j] == ip4[i][2]:
                    barr[j] = ip4[i][1]
    c = []
    for i in range(ip2):
        c.append(barr[i])
    return c


########## Greedy Businessman #####
def greedy(ip1, ip2):
    count = 0
    k = 0
    arr = [0] * (ip1 * 2)
    for i in range(ip1):
        arr[k] = ip2[0][i]
        arr[k + 1] = ip2[1][i]
        k += 2
    for i in range(0, k - 1):
        if (arr[i] >= arr[i + 1]):
            count += 1
    if (count == 0):
        return ip1
    else:
        return count


ip1 = int(input())
ip2 = []
b = []
for i in range(ip1):
    a = list(map(int, input().split()))
    b.append(a[1])
    ip2.append(a)
print(greedy(ip1, ip2))


############# Great Battle ##########
def battle(n, m, a):
    l = [0] * 1000
    ans = []
    for i in range(1000):
        l[i] = 1
    for i in range(m):
        l[a[i]] = 0
    for i in range(1, n + 1):
        if (l[i] == 1):
            ans.append(i)
        else:
            if (2 * i <= n):
                l[2 * i] = 0
            if (2 * i + 1 <= n):
                l[2 * i + 1] = 0
    return ans


n = int(input())
m = int(input())
a = list(map(int, input().split()))
print(battle(n, m, a))


############## Halindrome #############
def halindrome(n, arr):
    arr1 = [i[::-1] for i in arr]
    count = 0
    for i in range(len(arr)):
        if arr[i] == arr1[i]:
            count += 1
    return count


n = int(input())
arr = input().split()
print(halindrome(n, arr))


######## Harold & Homework:-###########
def harold(n, arr1, arr2):
    sum = 0
    for i in range(n):
        for j in range(i + 1, n):
            if arr2[i] == arr2[j]:
                if arr1[i] > arr1[j]:
                    arr1[j] = 0
                else:
                    arr1[i] = 0
    for i in range(n):
        sum += arr1[i]
    return sum


############ Jim's OS #############
def jims_OS(n, a1, a2):
    sum = 0
    for i in range(n):
        for j in range(i + 1, n):
            if a1[i] > a1[j]:
                temp = a1[i]
                a1[i] = a1[j]
                a1[j] = temp

                temp1 = a2[i]
                a2[i] = a2[j]
                a2[j] = temp1
    sum = a1[0] + a2[0]
    for i in range(1, n):
        if sum > a1[i]:
            sum += a2[i]
        else:
            m = a1[i] - sum
            sum += a2[i] + m
    return sum


########### LCS with vowels ###########
def LCS(ip1, ip2):
    l1 = [0] * 5
    l2 = [0] * 5
    count = 0
    ch = ['a', 'e', 'i', 'o', 'u']
    for i in range(0, len(ip1)):
        for j in range(0, 5):
            if ip1[i] == ch[j]:
                l1[j] += 1
    for i in range(0, len(ip2)):
        for j in range(0, 5):
            if ip2[i] == ch[j]:
                l2[j] += 1
    for i in range(0, 5):
        count += min(l1[i], l2[i])
    return count


####### Largest Prime Divisor:-##########
def prime(n):
    count = 0
    for i in range(2, n):
        if (n % i == 0):
            count += 1
    if (count == 0):
        return 1


def largest_prime(num):
    max = -1
    for i in range(2, num):
        if (num % i == 0):
            if (prime(i) == 1):
                max = i
    return max


######### Love Letter ###########
def love_letter(str, k):
    strRotate = str.split()
    for i in range(k):
        for j in range(len(strRotate)):
            strRotate[j] = strRotate[j][:1] + strRotate[j][0]
        count = 0
        for k in range(len(strRotate)):
            if strRotate[k] in str:
                count += 1
    print(count)


######## Mars Stone:-#############
def mars_stone(arr1, arr2, n, m):
    c = 0
    sum = 0
    for i in range(n):
        for j in range(m):
            if (arr1[i] == arr2[j]):
                arr1[i] = 0
    for i in range(n):
        if (arr1[i] != 0):
            sum = sum + arr1[i]
            if (sum <= n):
                c += 1
    return c


############ Machine #############
def machine(ip1, ip2):
    sum = 0
    pro = 1
    temp = 0
    a = 0
    temp = ip2 - ((ip1 * 2) - 1) + 1
    a = temp
    for i in range(1, a + 1):
        sum += (temp) * i
        temp -= 1
    while ip1 != 0:
        pro *= ip1
        ip1 -= 1
    return (sum * pro)


ip1 = int(input())
ip2 = int(input())
print(machine(ip1, ip2))


####### Missing Marble:-###########
def missing_marble(n, arr):
    num = arr[0] + arr[n - 1]
    j = n - 1
    ans = 0
    for i in range(n):
        if (arr[i] + arr[j]) != num:
            ans = num - arr[i]
            elif i == j:
            ans = num - arr[i]
    j = j - 1


return ans


####### Morse Code:-############
def morse(n, b):
    y = len(b)
    c = 0
    i = 0
    while n != 0:
        if b[i][0] == "." and b[i][len(b[i]) - 1] == "-":
            d = b[i].count('.')
            e = b[i].count('-')
            if d == e:
                c += 1
        n -= 1
        i += 1
    return c


########## Mr mayer exam:-###############
def myer(n, arr):
    sum = 0
    count = 0
    arr.sort()
    for i in range(n):
        j = i - 1
        while (j >= 0):
            if arr[i] == arr[j]:
                count += 1
                arr[i] = arr[i - 1] + 1
            j -= 1
    for i in range(n):
        # arr
        sum += arr[i]
    return sum


############# Parents ###############
def parents(ip1, ip2, ip3):
    c = 0
    i = 0
    while i < ip1:
        if ip3.count(i) >= ip2:
            c += 1
        i += 1
    if c == 0:
        return -1
    else:
        return c


######## Placement season begin:-############
def placement(num, arr1):
    c = 0
    arr2 = []
    for i in range(num):
        for j in range(i + 1):
            if arr1[j] > arr1[i]:
                c += 1
            else:
                pass
        arr2.append(c)
        c = 0
    return arr2


########## Picnic #################
def picnics(n, arr):
    count = 0
    ll = []
    i = 0
    while i < n:
        if arr[i] in ll:
            count += 1
            ll.clear()
        elif arr[i] not in ll:
            ll.append(arr[i])
        i += 1
    return count


n = int(input())
arr = list(map(int, input().split()))[:n]
print(picnics(n, arr))


########### Planting Tree ##########
def planting_tree(n, k):
    a = 2
    res = (a + n) % k
    return res
    OR


q = []
q.append(2)
for i in range(n):
    v = q.pop()
    for j in range(0, (v + 1) % k, 1):
        q.append(j)
return len(q)


########### Reducing dishes:-##########
def dishes(i1, i2):
    c = 2
    s = i2[0]
    for i in range(i1):
        if i2[i] >= 0:
            s += i2[i] * c
            c += 1
    return s


############ Race #############
def race(ip1, ip2):
    s = []
    for i in ip2:
        t = [] + [0] * (i[0] - 1)
        for j in range(i[0], i[1]):
            t = t + [1]
        s = s + [t + [0] * (max(b) - len(t))]
    x = []
    for i in range(max(b)):
        c = 0
        for j in range(len(s)):
            if s[j][i] == 1:
                c += 1
        x.append(c)
    return max(x)


ip1 = int(input())
ip2 = []
b = []
for i in range(ip1):
    a = list(map(int, input().split()))
    b.append(a[1])
    ip2.append(a)
print(race(ip1, ip2))


############ Representative ##########
def representative(n, arr, k):
    list = []
    temp = []
    ditt = []
    d = 9999
    arr.sort(reverse=True)
    if k == 1:
        return max(arr)
    else:
        for i in range(n - 1):
            ditt = arr[i] - arr[i + 1]
            if ditt < d:
                c = i
                d = ditt
        for i in range(k):
            temp.append(arr[c])
            c += 1
        temp.sort()
        return temp


########## Sapna problem solving #########
def sapna(n, str):
    t = 240 - str
    c = 0
    q = 0
    for i in range(n):
        q += 5 * i
        if q <= t:
            c += 1
    return c


n, str = list(int(i) for i in input().split())
print(sapna(n, str))


######### Serena Flower:-###########
def serena(n, k, arr):
    count = 0
    i = 1
    j = 0
    for i in range(k):
        for j in range(i):
            if (arr[i] == arr[j]):
                break
            j += 1
        if (i == j):
            count += 1
        i += 1
    return count


########## Sibling:-##############
def identify_siblings(n, arr, x):
    index = arr.index(x)
    level = 0
    start_index = level
    number_of_nodes = 0
    while start_index < n:
        end_index = pow(2, level) + start_index
        if x in arr[start_index:end_index]:
            break
        level += 1
        start_index = (2 * start_index) + 1
    final_array = arr[start_index:end_index]
    final_array.remove(x)
    return set(final_array) if final_array else {-1}


########## Shunting Yard Problem ##########
def shunting_yard(str):
    return int(eval(str))
    str = input()


print(shunting_yard(str))


######### Social Network ############
def prime(num):
    if num > 1:
        for i in range(2, num):
            if num % i == 0:
                return 0
    return 1


def social(n):
    count = 1
    for i in range(2, n + 2):
        if prime(i) == 1 and i * 2 > n + 1:
            count += 1
    if n <= 2:
        count -= 1
    return count


n = int(input())
print(social(n))


########## Special Unit ############
def special_unit(n, a):
    a.sort()
    count = 0
    i = 0
    while (i < n - 1):
        if (a[i + 1] <= a[i]):
            a[i + 1] = a[i + 1] + 1
            count += 1
            i = i - 1
        i += 1
    return count


########### Stick Game ################
def stick_game(n, arr):
    sum = 0
    for i in range(0, n, 2):
        if arr[i] > arr[i + 1]:
            sum += arr[i + 1]
        else:
            sum += arr[i]
    return sum


########### Stocks ############
def stocks(n, arr):
    sum = 0
    for i in range(n):
        if arr[i] < 0:
            sum += arr[i]
        else:
            break
    return sum
    OR


def stocks(n, arr):
    price = 0
    best_price = 0
    for i in range(n):
        price += arr[i]
        if best_price > price:
            best_price = price
    return best_price


######### Street Light #############
def street_light(n, arr1):
    d = 0
    c = 0
    for i in range(n):
        arr2 = []
        x, y = map(int, input().split())
        arr2.append(x)
        arr2.append(y)
        arr1.append(arr2)
    for j in range(n):
        if arr1[j][0] < d:
            s = d
        else:
            s = arr1[j][0]
        e = arr1[j][1]
        c += e - s
        d = arr1[j][1]
    return c

    OR


def street_light(n, arr1):
    sum1 = 0
    sum2 = 0
    l = len(arr1) - 1
    for i in arr1:
        sum1 = sum1 + i[1] - i[0]
    for j in range(0, l):
        if arr1[j + 1][0] < arr1[j][1]:
            sum2 = sum2 + (arr1[j][1] - arr1[j + 1][0])
    return (sum1 - sum2)


n = int(input())
arr1 = []
for i in range(n):
    arr2 = []
    x, y = map(int, input().split())
    arr2.append(x)
    arr2.append(y)
    arr1.append(arr2)
print(street_light(n, arr1))


########## String Rotation ############
def string_rotate(s1, s2):
    numberRotation = 0
    temp = s1
    nomatch = False
    while temp != s2:
        numberRotation += 1
        temp = s1[len(s2) - numberRotation:] + s1[0:len(s1) - numberRotation]
        if numberRotation >= len(s1):
            temp = s2
            nomatch = True
    if nomatch:
        print("No Match")
    else:
        print(str(numberRotation))


########### Subject Marks ############
def subject_marks(n, arr):
    sum = 0
    for i in range(n):
        if arr[i] < arr[i - 1]:
            arr[i] = arr[i - 1] + 1
        sum += arr[i - 1]
    sum += arr[len(arr) - 1]
    return sum


n = int(input())
arr = list(map(int, input().split()))
print(subject_marks(n, arr))


############# University ###########
def university(ip1, ip2, ip3, ip4):
    count = 0
    for i in range(len(ip4)):
        for j in range(len(ip2)):
            if ip4[i] > ip2[j]:
                count += 1
    return count


ip1 = int(input())
ip2 = list(map(int, input().split()))
ip3 = int(input())
ip4 = list(map(int, input().split()))
print(university(ip1, ip2, ip3, ip4))


######### Wedding Game ###########
def wedding(s, y):
    count = 0
    n = 0
    l = len(s)
    for i in range(l):
        n = n * 10 + int(s[i])
        if n <= y:
            x = 1
            continue
        else:
            if x:
                count += 1
                n = int(s[i])
                x = 0
            if n <= y:
                x = 1
            else:
                num = 0
    if x:
        count += 1
    return count


######### X_mus Eve ############
solCount = 0


def collect(remAmount, remHouse, prevAmount):
    global solCount
    if remHouse == 0:
        return
    if remAmount < 0:
        return
    if remAmount == 0:
        solCount += 1
        return
    for i in range(1, prevAmount, 1):
        collect(remAmount - i, remHouse - 1, i)


def solution(amount, house):
    for i in range(0, amount + 1):
        collect(amount - i, house - 1, i)
    return solCount


######### Zombie Apoclypes #########
def zombie_apoclypes(n, arr, k):
    contagious = 1
    zombies = 0
    day = 1
    arr[1] = 0
    while (zombies < n):
        day += 1
        arr[day] = contagious
        zombies += arr[day]
        if (day - k + 1 >= 1):
            contagious += arr[day - k + 1]
    return day


########## Zombies ###############
def gcd(a, b):
    if (a == 0):
        return b
    else:
        return gcd(b % a, a)


def zombies(arr, n):
    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            if (gcd(arr[i], arr[i + 1]) == 1):
                return i
    return -1























