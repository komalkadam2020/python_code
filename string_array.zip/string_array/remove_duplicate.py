str1 = input("Enter a String : ")
x = []

for i in range(len(str1)):
    if str1[i] not in x:
        x.append(str1[i])
    else:
        pass
for i in range(len(x)):
    print(x[i], end=" ")
