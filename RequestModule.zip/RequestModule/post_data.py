import requests
import warnings
import json

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

url = 'https://httpbin.org/post'
form_data = {'user1': 'value1'}
server = requests.post(url, data=form_data, verify=False)
output = server.text
status = server.status_code
print(status, server.reason)

print('The response from the server is: \n', output)


''''# Define new data to create
new_data = {
    "userID": 1,
    "id": 11,
    "title": "Making a POST request",
    "body": "This is the data we created."
}

url_post = "https://jsonplaceholder.typicode.com/posts"

# A POST request to tthe API
post_response = requests.post(url_post, json=new_data, verify=False)

# Print the response
post_response_json = post_response.json()
print(post_response_json)'''
