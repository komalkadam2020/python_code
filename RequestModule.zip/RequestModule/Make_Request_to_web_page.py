import requests
import warnings
import json

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# Making a GET request
g = requests.get('https://api.github.com/users/naveenkrnl', verify=False)
g_dict = g.json()

data = json.dumps(g_dict, indent=3)

# check status code for response received
# success code - 200
print(g, g.reason)

# print content of request
print(data)
print('get a value of key: login: ', g.json().get('login'))

print('---------------------------------------------------------------------------------------------------------')
















'''# Making a POST request
r = requests.post('https://api.github.com/users/naveenkrnl', data={'key': 'value'}, verify=False)

# check status code for response received
# success code - 200
print(r, r.reason)
# print content of request
print(r.json())'''
