import re
import json
import logging

log_file = "syslog.txt"
logging.basicConfig(filename='output.txt', filemode='w', level=logging.DEBUG)
dict1 = {"error": [], "warning": [], "info": []}
error_count, warning_count, info_count = 0, 0, 0
try:
    with open(log_file, "r") as log_lines:

        for i, line in enumerate(log_lines, start=1):
            # Define the regular expression to extract the information from the log line
            regex = r"^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+\S+\[\d+\]:\s+<(\S+)>.*\s(\S+)\s=>\s'(\S+)'"
            match = re.match(regex, line)

            if match:
                # Extract the date, time, message type, and message from the log line
                date_time = match.group(1)
                msg_type = match.group(2)
                message = match.group(3)

                output_line = f"Line_no:{i + 1} {date_time} {msg_type} {message}"

                if 'error' in line:
                    error_count += 1
                    dict1["error"].append(output_line)
                elif 'info' in line:
                    info_count += 1
                    dict1["info"].append(output_line)
                elif 'warning' in line:
                    warning_count += 1
                    dict1["warning"].append(output_line)
        e = json.dumps(dict1['error'], indent=2)
        w = json.dumps(dict1['warning'], indent=2)
        i = json.dumps(dict1['info'], indent=2)

        if not dict1['error']:
            logging.error("No Error")
        else:
            logging.error(e)

        if not dict1['warning']:
            logging.error("No Warning")
        else:
            logging.warning(w)

        if not dict1['info']:
            logging.error("No Info")
        else:
            logging.info(i)

        print('Total number of Error: ', error_count)
        print('Total number of warning: ', warning_count)
        print('Total number of info: ', info_count)
except Exception as e:
    print(str(e))
    logging.error(str(e))

'''
import re

log_file = "syslog.txt"

with open(log_file, "r") as f:
    log_lines = f.readlines()

for line in log_lines:
    # Define the regular expression to extract the information from the log line
    regex = r"^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+\S+\[\d+\]:\s+<(\S+)>.*\s(\S+)\s=>\s'(\S+)'"
    match = re.match(regex, line)

    if match:
        # Extract the date, time, message type, and message from the log line
        date_time = match.group(1)
        msg_type = match.group(2)
        message = match.group(3)

        # Print the extracted information
        print(f"Date/time: {date_time}")
        print(f"Message type: {msg_type}")
        print(f"Message: {message}")
'''
