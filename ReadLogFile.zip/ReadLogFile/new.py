#import logging
#print(dir(logging))
import re

# Define the regular expression pattern give word start with 'opt'
pattern = r"\bopt\w*"

# Define a regular expression pattern to match words that end with "path"
pattern1 = r"\b\w*path\b"

# This will print start from 'option' to end with 'routes'
pattern3 = r"\boption.*routes\b"

pattern4 = r"\boption.*?=>\b"


# Open the file for reading
with open("syslog.txt", "r") as file:
    # Read the entire file contents into a string
    file_contents = file.read()

    # Use re.findall() to find all occurrences of the pattern in the string
    matches = re.findall(pattern3, file_contents)

    # Print the matched words
    print(matches)
