import logging
import json

logging.basicConfig(filename='output.txt', filemode='w', level=logging.DEBUG)
dict1 = {"error": [], "warning": [], "info": []}
error_count, warning_count, info_count = 0, 0, 0

# Open the log file for reading
try:
    with open("syslog.txt", "r") as log_file:
        # read each line in the log file
        for i, line in enumerate(log_file, start=1):
            # Extract the date, time, message type, and message content
            date_time = " ".join(line.split()[:3])
            message_type = line.split()[5]
            message_content = ''
            if "(wlan0):" in line:
                message_content = line.split("(wlan0):")[1].strip().split(" => ")[0]

            # Create a new string with the extracted information
            output_line = f"Line_no:{i+1}  {date_time} {message_type} {message_content}"

            if 'error' in line:
                error_count += 1
                dict1["error"].append(output_line)
            elif 'info' in line:
                info_count += 1
                dict1["info"].append(output_line)
            elif 'warning' in line:
                warning_count += 1
                dict1["warning"].append(output_line)
            else:
                pass
    e = json.dumps(dict1['error'], indent=2)
    w = json.dumps(dict1['warning'], indent=2)
    i = json.dumps(dict1['info'], indent=2)

    if not dict1['error']:
        logging.error("No Error")
    else:
        logging.error(e)

    if not dict1['warning']:
        logging.error("No Warning")
    else:
        logging.warning(w)

    if not dict1['info']:
        logging.error("No Info")
    else:
        logging.info(i)

    print('Total number of Error: ', error_count)
    print('Total number of warning: ', warning_count)
    print('Total number of info: ', info_count)
except Exception as e:
    print(str(e))
    logging.error(str(e))














'''
import logging
import json

logging.basicConfig(filename='output.txt', filemode='w', level=logging.DEBUG)
dict1 = {"error": [], "warning": [], "info": []}
error_count, warning_count, info_count = 0, 0, 0

# Open the log file for reading
try:
    with open("syslog.txt", "r") as log_file:
        # read each line in the log file
        for line in log_file:
            # Extract the date, time, message type, and message content
            date_time = " ".join(line.split()[:3])
            message_type = line.split()[5]
            message_content = None
            if "(wlan0):" in line:
                message_content = line.split("(wlan0):")[1].strip().split(" => ")[0]

            # Create a new string with the extracted information
            output_line = f"{date_time} {message_type} {message_content}"

            if 'error' in line:
                error_count += 1
                dict1["error"].append(output_line)
            elif 'info' in line:
                info_count += 1
                dict1["info"].append(output_line)
            elif 'warning' in line:
                warning_count += 1
                dict1["warning"].append(output_line)
            else:
                print()
    e = json.dumps(dict1['error'], indent=2)
    w = json.dumps(dict1['warning'], indent=2)
    i = json.dumps(dict1['info'], indent=2)

    if not dict1['error']:
        logging.error("No Error")
    else:
        logging.error(e)

    if not dict1['warning']:
        logging.error("No Warning")
    else:
        logging.warning(w)

    if not dict1['info']:
        logging.error("No Info")
    else:
        logging.info(i)

    print('Total number of Error: ', error_count)
    print('Total number of warning: ', warning_count)
    print('Total number of info: ', info_count)
except Exception as e:
    print(str(e))
    logging.error(str(e))
'''