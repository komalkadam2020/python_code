import subprocess

# Run the journalctl command and capture the output as a string
cmd = "journalctl --since 'yesterday' --no-pager"
result = subprocess.run(cmd.split(), stdout=subprocess.PIPE)
output = result.stdout.decode()

# Split the log messages by newline characters and filter out empty lines
lines = output.split('\n')
lines = [line for line in lines if line]

# Separate the log messages by severity into different lists
error_messages = []
warning_messages = []
info_messages = []

for line in lines:
    # Extract the date, time, severity, and message content from each log message
    parts = line.split(' ', 5)
    date = parts[0]
    time = parts[1]
    severity = parts[4].strip('[]')
    message = parts[5]

    # Append the message to the appropriate list based on its severity
    if severity == 'error':
        error_messages.append((date, time, severity, message))
    elif severity == 'warning':
        warning_messages.append((date, time, severity, message))
    elif severity == 'info':
        info_messages.append((date, time, severity, message))

# Print out each log message with its corresponding date, time, severity, and message content
print("Error messages:")
for msg in error_messages:
    print(f"{msg[0]} {msg[1]} {msg[2]}: {msg[3]}")

print("Warning messages:")
for msg in warning_messages:
    print(f"{msg[0]} {msg[1]} {msg[2]}: {msg[3]}")

print("Info messages:")
for msg in info_messages:
    print(f"{msg[0]} {msg[1]} {msg[2]}: {msg[3]}")
