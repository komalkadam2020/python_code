import re

log_file = 'syslog.txt'

info_dict = {"info": {}, "warning": {}, "error": {}}

with open(log_file, "r") as log_lines:
    for i, line in enumerate(log_lines):
        match = re.match(r"(.+) NetworkManager\[\d+\]: <(\w+)> +\[(\d+\.\d+)\] (.+)", line)
        print(match)
        if match:
            date_time, msg_type, _, message = match.groups()
            if msg_type == "info":
                info_dict["info"][i] = {"date_time": date_time, "message": message}
            elif msg_type == "warning":
                info_dict["warning"][i] = {"date_time": date_time, "message": message}
            elif msg_type == "error":
                info_dict["error"][i] = {"date_time": date_time, "message": message}

for msg_type in ["info", "warning", "error"]:
    print(msg_type.upper())
    print("-" * 40)
    for line_number, info in info_dict[msg_type].items():
        print(f"{info['date_time']} [{msg_type}] {info['message']} (line {line_number})")
    print("\n")

