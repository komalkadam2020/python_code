import re

log_line = "Feb 23 19:45:09 lpz-ee212092 NetworkManager[522]: <info>  [1677161709.0184] dhcp4 (wlan0): option requested_time_offset => '1'"

regex = r"^(\w+\s+\d+\s+\d+:\d+:\d+)\s+(\S+)\s+(\S+)\[(\d+)\]:\s+<(\S+)>.*\s(\S+)\s=>\s'(\S+)'\s*(.*)$"
match = re.match(regex, log_line)

if match:
    date_time = match.group(1)
    msg_type = match.group(5)
    dhcp_option = match.group(6)

    '''hostname = match.group(2)
    app_name = match.group(3)
    pid = match.group(4)
    msg_type = match.group(5)
    dhcp_option = match.group(6)
    option_value = match.group(7)
    additional_text = match.group(8)'''
    if msg_type == 'info':
        i = f"{date_time} <{msg_type}> {dhcp_option}"
        print(i)
    '''print(f"Hostname: {hostname}")
    print(f"Application name: {app_name}")
    print(f"Process ID: {pid}")
    print(f"Message type: {msg_type}")
    print(f"DHCP option: {dhcp_option}")
    print(f"Option value: {option_value}")
    print(f"Additional text: {additional_text}")'''
else:
    print("No match found")











'''
import re

log_line = "Feb 23 19:45:09 lpz-ee212092 NetworkManager[522]: <info>  [1677161709.0184] dhcp4 (wlan0): option requested_time_offset => '1'"

# Define regular expression pattern
pattern = r'^(\w{3}\s+\d+\s\d{2}:\d{2}:\d{2})'
pattern2 = r'\s<(\w+)>'


pattern1 = r'^(\w{3}\s+\d+\s\d{2}:\d{2}:\d{2})\s(\w+)\[(\d+)\]:\s<(\w+)>\s+(.*)$'
          #r'\s(\w+)\[(\d+)\]:\s<(\w+)>\s+(.*)$'

# Match pattern against log line
match = re.match(pattern2, log_line)
print(match)
# Check if match is not None before accessing its groups
if match is not None:
    # Extract date, time, message type, and message from groups
    date_time = match.group(1)
    #message_type = match.group(4)
    #message = match.group(5)

    # Print results
    print(f"Date/Time: {date_time}")
    #print(f"Message Type: {message_type}")
    #print(f"Message: {message}")
else:
    print("No match found for log line.")


'''
