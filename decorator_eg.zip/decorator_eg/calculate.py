# pass function as a argument

def add(x, y):
    return x + y


def sub(x, y):
    return x - y


def calculate(func, x, y):
    return func(x, y)


result = calculate(add, 4, 6)
print(result)  # prints 10

result1 = calculate(sub, 10, 4)
print(result1)  # prints 6


''' calculate() function taking function as a its argument.
While calling calculate(), we are passing the add() or sub() function as the argument.
func(x,y) become add(x,y)
'''