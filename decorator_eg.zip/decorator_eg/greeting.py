# return a function a value

def greeting(name):
    def hello():
        return "Welcome, " + name
    return hello()


greet = greeting("kk")
print(greet)
