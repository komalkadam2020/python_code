# here use of + operator with different behaviour

# + operator with numbers
num1 = 5
num2 = 4
res = num1 + num2
print(res)

# + operator with strings
str1 = 'string1'
str2 = 'string2'
res1 = str1 + str2
print(res1)

# here use of len() method with different behaviour

str3 = 'students'
list1 = ['rohan', 'Aman', 'akash', 'rahul']
dict1 = {1: 'rohan', 2: 'Aman', 3: 'akash'}

print(len(str3))  # length of string
print(len(list1))  # number of list item
print(len(dict1))  # number of keys
