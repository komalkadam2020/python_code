# class 1 Tomato
class Tomato():
    def type(self):
        print("Vegetable")
    def color(self):
        print("Red")

# class 2 Apple
class Apple():
    def type(self):
        print("fruit")
    def color(self):
        print('Red')

def func(obj):
    obj.type()
    obj.color()

obj_tomato = Tomato()
obj_apple = Apple()
func(obj_tomato)
func(obj_apple)