# Base class
class Vehicle:
    def Vehicle_info(self):
        print('Inside vehicle class')

# Child class 1
class Car(Vehicle):
    def car_info(self):
        print('Inside car class ')

# Child class 2
class SportCar(Car):
    def sport_car_info(self):
        print('Inside Sportcar class')

object = SportCar()

object.Vehicle_info()
object.car_info()
object.sport_car_info()