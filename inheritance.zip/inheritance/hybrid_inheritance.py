class Vehicle:
    def vehicle_info(self):
        print("inside Vehicle class ")

class Car(Vehicle):
    def car_info(self):
        print("Inside Car class")

class Truck(Vehicle):
    def truck_info(self):
        print('Inside Truck class ')

# Sport car can inherits properties of vehicle and car
class SportCar(Car, Vehicle):
    def sport_car_info(self):
        print('Inside sportCar class')

sportCar = SportCar()

sportCar.vehicle_info()
sportCar.car_info()
sportCar.sport_car_info()