# base class
class Vehicle:
    def Vehicle_info(self):
        print('Inside Vehicle class ')

# Child class
class Car(Vehicle):
    def car_info(self):
        print('Inside Car class')

# Create object of Car
car = Car()

# Access vehicle info using car object
car.Vehicle_info()
car.car_info()