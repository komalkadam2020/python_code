# parent class 1
class Person:
    def person_info(self, name, age):
        print("Inside Preson class ")
        print('name: ', name, 'Age: ', age)

# parent class 2
class Company:
    def company_info(self, company_name, location):
        print("Inside Company class ")
        print('name: ', company_name, 'location: ', location)

# Child class
class Employee(Person, Company):
    def Employee_info(self, salary, skill):
        print("inside employee class")
        print('Salary: ', salary, 'Skill: ', skill)


# create object of employee
emp = Employee()

emp.person_info('kk', 22)
emp.company_info('Sasken', 'Pune')
emp.Employee_info(15000, 'Python')