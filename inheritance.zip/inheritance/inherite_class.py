class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def say_hello(self):
        print(f"Hello, my name is {self.name} and I'm {self.age} years old.")


class Employee(Person):
    def __init__(self, name, age, salary):
        super().__init__(name, age)
        self.salary = salary

    def get_salary(self):
        return self.salary


employee = Employee("Bob", 40, 50000)
employee.say_hello()  # Output: Hello, my name is Bob and I'm 40 years old.
print(employee.get_salary())  # Output: 50000
