import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-f', '--file', help='input file')
parser.add_argument('-o', '--output', help='output file')
args = parser.parse_args()

if args.file:
    print('Input file:', args.file)
if args.output:
    print('Output file:', args.output)
