import socket
import time

import TcpData_pb2


class TcpTransmitter:
    def __init__(self, address, port):
        self.address = address
        self.port = port

        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(3)
            print("Socket created successfully")
        except socket.error as err:
            print("Failed to create socket: ", err)

        self.socket.connect((self.address, self.port))

    def send_data(self, message):
        tcp_message = TcpData_pb2.TcpData()
        tcp_message.message = message
        tcp_message.port = self.port
        time.sleep(2)
        self.socket.sendall(tcp_message.SerializeToString())
        print('Message send successfully...')

    def close(self):
        self.socket.close()


if __name__ == "__main__":
    try:
        transmitter = TcpTransmitter("localhost", 12344)
        transmitter.send_data("Hello, world!")
        transmitter.close()
    except Exception as e:
        print(f"ERROR OCCURRED..!!! {e}")
