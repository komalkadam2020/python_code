import socket
import TcpData_pb2


class TcpReceiver:
    def __init__(self, address, port):
        self.address = address
        self.port = port

        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            print("Socket created successfully")
        except socket.error as err:
            print("Failed to create socket: ", err)

        self.socket.bind((self.address, self.port))
        self.socket.listen(1)

    def receive_data(self):
        conn, addr = self.socket.accept()
        data = b""
        while True:
            res = conn.recv(1024)
            if not res:
                break
            data += res
        tcp_message = TcpData_pb2.TcpData()
        tcp_message.ParseFromString(data)
        conn.close()
        return tcp_message.message, tcp_message.port

    def close(self):
        self.socket.close()


if __name__ == "__main__":
    try:
        receiver = TcpReceiver("localhost", 12344)
        message, port = receiver.receive_data()
        print(f"Received message '{message}' on port {port}")
        receiver.close()
    except Exception as e:
        print(f"ERROR OCCURRED..!!! {e}")

