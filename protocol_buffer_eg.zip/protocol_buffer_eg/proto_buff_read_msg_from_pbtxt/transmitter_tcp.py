import socket
import tcp_data_pb2
import google.protobuf.text_format as text_format
import signal
import time


class TCPTransmitter:
    def __init__(self, host, port):
        self.host = host
        self.port = port

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # Set up signal handler for SIGINT (Ctrl-C)
        signal.signal(signal.SIGINT, self.handle_signal)

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def connect(self):
        try:
            self.sock.connect((self.host, self.port))
            print(f"Connected to {self.host} PORT:{self.port}")
        except socket.error as e:
            print(f"An error occurred while connecting: {e}")
            raise e

    def handle_signal(self, signum, frame):
        print("INTERRUPT OCCURRED..!!! EXITING Transmitter...: ")
        self.close()
        exit()

    def send_message(self):
        try:
            # Read message from .pbtxt file
            message = self.read_message()

            # Parse message
            tcp_data = self.parse_message(message)

            # Send message
            self.send_tcp_data(tcp_data)

            # Receive acknowledgement
            self.receive_acknowledgement()

            # Print all details to console
            self.print_tcp_data(tcp_data)

        except (socket.error, KeyError) as e:
            print(f"An error occurred while sending message: {e}")
            raise e

    def read_message(self):
        with open("messages.pbtxt", "r") as f:
            message = f.read()
        return message

    def parse_message(self, message):
        tcp_data = tcp_data_pb2.StudentList()
        text_format.Merge(message, tcp_data)
        return tcp_data

    def send_tcp_data(self, tcp_data):
        data = tcp_data.SerializeToString()
        self.sock.sendall(data)
        print('Messages send successfully...')
        time.sleep(2)

    def receive_acknowledgement(self):
        ack = self.sock.recv(1024)
        print(f"Acknowledgement received: {ack.decode()}")

    def print_tcp_data(self, tcp_data):
        '''
        print(f"ID: {tcp_data.student_id}")
        print(f"Name: {tcp_data.student_name}")
        print(f"Age: {tcp_data.age}")
        print(f"Address: {tcp_data.address}")
        print(f"Phone Numbers: {', '.join(tcp_data.phone_number)}")
        '''

    def close(self):
        try:
            self.sock.close()
        except socket.error as e:
            print(f"An error occurred while closing socket: {e}")
            raise e


if __name__ == "__main__":
    HOST = 'localhost'
    PORT = 5046
    try:
        with TCPTransmitter(HOST, PORT) as transmitter:
            transmitter.send_message()
    except Exception as e:
        print(f"An error occurred on server side: {e}")
