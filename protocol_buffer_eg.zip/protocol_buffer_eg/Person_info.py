import Person_pb2

person = Person_pb2.Person()
person.name = "Alice"
person.id = 123
person.email = "alice@example.com"

serialized_person = person.SerializeToString()
print(serialized_person)

person.ParseFromString(serialized_person)

print(person.name)
print(person.id)
print(person.email)
