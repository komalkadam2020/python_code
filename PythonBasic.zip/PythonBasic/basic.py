a = 5
print('value of a : ', a)
