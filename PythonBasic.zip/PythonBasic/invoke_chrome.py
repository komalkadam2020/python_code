from selenium import webdriver
from selenium.webdriver.chrome.service import Service

service_obj = Service("/usr/bin/google-chrome")

driver = webdriver.Chrome(service=service_obj)
driver.get("https://jam.sasken.com/home")
print(driver.title)
print(driver.current_url)
driver.close()
