import math


def test_sqrt():
    num = 25
    assert math.sqrt(num) == 5


def test_square():
    num = 7
    assert 7 * 7 == 40


def test_equality():
    assert 10 == 11


def test_file1_method1():
    x = 5
    y = 6
    assert x + 1 == y, "test failed"


def test_file1_method2():
    x = 5
    y = 6
    assert x + 1 == y, "test failed"
