import pytest


@pytest.mark.group1
def test_firstProgram():
    print('Hello')


def test_secondGreetCreditcard():
    print('Good morning')

