import pytest


# assert is used to continue execution if given condition evaluate trues

@pytest.mark.group1
@pytest.mark.skip
def test_firstProgram():
    msg = "Hello"
    assert msg == 'hi', 'test failed because value does not match..!!'


def test_second_add():
    a = 5
    assert a + 2 == 7, "Test failed no value match with a"


def test_fixtureDemo(setup):
    print('I will execute steps in fixture')
