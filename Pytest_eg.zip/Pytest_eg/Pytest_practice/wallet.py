
class InsufficientAmount(Exception):
    pass


class Wallet:

    def __init__(self, initial_amount=0):
        self.balance = initial_amount

    def spend_cash(self, amount):
        if self.balance < amount:
            print('Not enough amount available to spend {}'.format(amount))
            raise InsufficientAmount('Not enough available to spend {}'.format(amount))
        else:
            self.balance = self.balance - amount

    def add_cash(self, amount):
        self.balance = self.balance + amount


#obj = Wallet()
#obj.add_cash(500)
#obj.spend_cash(2011)
#print(obj.balance)