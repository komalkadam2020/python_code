import pytest
from wallet import Wallet
import conftest


def test_initial_amount(empty_wallet):
    assert empty_wallet.balance == 0


def test_set_initial_amt(wallet):
    assert wallet.balance == 100


def test_add_cash(wallet):
    wallet.add_cash(50)
    assert wallet.balance == 150


def test_spend_cash(wallet):
    wallet.spend_cash(150)
    #assert wallet.balance == 50

