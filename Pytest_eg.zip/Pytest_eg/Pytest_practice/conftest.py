import pytest
from wallet import Wallet


@pytest.fixture()
def empty_wallet():
    return Wallet()


@pytest.fixture()
def wallet():
    return Wallet(100)
