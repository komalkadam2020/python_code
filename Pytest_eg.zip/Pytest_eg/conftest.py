import pytest


@pytest.fixture()
def setup():
    print('This will executing first...')
    yield
    print('I will executed last..')


@pytest.fixture()
def dataLoad():
    print('User profile data is being created.')
    return ['komal', 'kadam', 'komalkadam@gmail.com']
