import re
import json
import logging

logging.basicConfig(filename='error.log',
                    filemode='w')
dict1 = {"error": [], "warning": [], "info": []}
with open('syslog.txt', 'r') as log:
    for line in log:
        err = re.findall("<error>", line)
        warn = re.findall("<warning>", line)
        info = re.findall("<info>", line)
        if err:
            dict1["error"].append(line)

        elif warn:
            dict1["warning"].append(line)

        elif info:
            dict1["info"].append(line)

# Print dict1
d = json.dumps(dict1, indent=5)
# print(d)

e = json.dumps(dict1['error'], indent=2)
# print(e)
logging.error(e)
