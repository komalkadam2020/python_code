class Employee:
    # class variable
    company_name = 'Sasken Technology '

    # constructor to initialize object
    def __init__(self, name, salary):
        # instance variable
        self.name = name
        self.salary = salary

    # instance method
    def show(self):
        print('Employee ', self.name, self.salary, self.company_name)


emp1 = Employee('komal', 15000)
emp1.show()

emp2 = Employee('abc', 12000)
print(emp2.salary)