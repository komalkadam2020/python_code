from Module_Logger import FileErrorLogger
import re
import json


class FileReader(FileErrorLogger):
    def read_file_and_log_errors(file_name):
        file_error_logger = FileErrorLogger()
        with open(file_name, 'r') as f:
            for i, line in enumerate(f, start=1):
                pattern = r"(.+) lpz-ee212092 NetworkManager\[\d+\]: <(\w+)> +\[(\d+\.\d+)\] (.+)"
                match = re.match(pattern, line)
                if match:
                    date_time = match.group(1)
                    msg_type = match.group(2)
                    message = match.group(4)

                output_line = f"{date_time} <{msg_type.upper()}> {message}"

                # Check for error condition in line
                if 'error' in line:
                    # Log error and add to dictionary
                    file_error_logger.log_error(i, output_line)

                elif 'warning' in line:
                    # Log error and add to dictionary
                    file_error_logger.log_warning(i, output_line)

                elif 'info' in line:
                    # Log error and add to dictionary
                    file_error_logger.log_info(i, output_line)

        # Return the error dictionary
        return file_error_logger.warning_dict

    # Example usage
    error_dict = read_file_and_log_errors('syslog.txt')
    print(error_dict)
