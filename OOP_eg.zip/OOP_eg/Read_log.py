from Module_Read_Log import Logger
import logging


class SyslogReader(Logger):

    def __init__(self, filename):
        self.filename = filename

    def read(self):
        try:
            with open(self.filename, 'r') as f:
                for line in f:
                    # for key in Logger.log_levels:
                    if 'error' in line:
                        logging.log(Logger.log_levels['error'], line.strip())
                    elif 'warning' in line:
                        logging.log(Logger.log_levels['warning'], line.strip())
                    elif 'info' in line:
                        logging.log(Logger.log_levels['info'], line.strip())

        except Exception as e:
            print(str(e))
            logging.error(str(e))


#reader = SyslogReader('syslog.txt')
#reader.read()
