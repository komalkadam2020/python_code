import logging


class FileErrorLogger:
    def __init__(self):
        logging.basicConfig(filename='output.log', level=logging.DEBUG, filemode='w')
        self.error_dict = {}
        self.warning_dict = {}
        self.info_dict = {}

    def log_error(self, line_num, error):
        self.error_dict[line_num] = error
        logging.error(f'Error in line {line_num}: {error}')

    def log_warning(self, line_num, warning):
        self.warning_dict[line_num] = warning
        logging.warning(f'warning in line {line_num}: {warning}')

    def log_info(self, line_num, info):
        self.info_dict[line_num] = info
        logging.info(f'info in line {line_num}: {info}')
