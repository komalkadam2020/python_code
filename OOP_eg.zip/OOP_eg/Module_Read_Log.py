import logging


class Logger:
    log_levels = {
        'error': logging.ERROR,
        'warning': logging.WARNING,
        'info': logging.INFO
    }

    logging.basicConfig(filename='output.log', level=logging.DEBUG, filemode='w')
