class Area:
    def __init__(self, length, breath):
        self.length = length
        self.breath = breath

    def Area_Rectangle(self):
        return 2 * (self.length + self.breath)


obj = Area(20, 10)
print(obj.Area_Rectangle())
