from Read_log import SyslogReader


def test_read_file():
    reader = SyslogReader('syslog1.txt')
    reader.read()
