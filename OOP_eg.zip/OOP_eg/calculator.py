class Add_Sub:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    # define 'add' method
    def add(self):
        return self.x + self.y

    # define 'subtract' method
    def subtract(self):
        return self.x - self.y

    # define 'multiply' method
    def multiply(self):
        return self.x * self.y

    # define 'divide' method
    def division(self):
        return self.x / self.y


obj = Add_Sub(10, 4)
print('Addition: ', obj.add())
print('Subtraction: ', obj.subtract())
print('Multiplication: ', obj.multiply())
print('Division: ', obj.division())
