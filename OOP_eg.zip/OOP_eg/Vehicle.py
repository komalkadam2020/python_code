class Vehicle:
    def __init__(self, max_speed, mileage):
        self.max_speed = max_speed
        self.mileage = mileage


obj = Vehicle(250, 20)
print(obj.mileage)
