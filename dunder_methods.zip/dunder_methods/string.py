class point:
    x = 5
    y = 3

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __str__(self):
        s = f'({self.x},{self.y})'
        return s


p1 = point(5, 4)
p2 = point(2, 3)
