import socket


class Receiver:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.addr = (self.host, self.port)
        self.receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def start(self):
        with open('output.log', 'w') as f:
            while True:
                data = input("Enter a message: ")
                data = data.encode('utf-8')
                # sending message to Transmitter
                self.receiver.sendto(data, self.addr)
                f.write(f'Receiver: {data.decode()}\n')

                # Received response from Transmitter
                data, addr = self.receiver.recvfrom(1024)
                data = data.decode('utf-8')
                f.write(f'Transmitter: {data}\n')
                print(f'Transmitter: {data}')


receiver = Receiver('localhost', 11111)
receiver.start()

























'''import socket


class Client:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.addr = (host, port)
        self.client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send_receive_msg(self):
        while True:
            data = input('Enter message : ')
            data = data.encode('utf-8')
            # sending msg to server
            self.client.sendto(data, self.addr)

            # Received response from server
            data, addr = self.client.recvfrom(1024)
            data = data.decode('utf-8')
            print(f'Server : {data}')


client = Client('localhost', 11111)
client.send_receive_msg()'''
