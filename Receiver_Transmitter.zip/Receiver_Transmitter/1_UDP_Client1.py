import socket

host = 'localhost'
port = 11111
addr = (host, port)

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:

    data = input("Enter a message: ")
    data = data.encode('utf-8')
    # sending message to Server
    client.sendto(data, addr)

    # Received response from server
    data, addr = client.recvfrom(1024)
    data = data.decode('utf-8')
    print(f'Server: {data}')

