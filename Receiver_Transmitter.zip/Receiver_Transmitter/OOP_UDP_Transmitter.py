import socket


class Transmitter:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.transmitter = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.transmitter.bind((self.host, self.port))

    def start(self):
        with open('output.log', 'w') as f:
            while True:
                # Received message from Receiver
                data, addr = self.transmitter.recvfrom(1024)
                data = data.decode('utf-8')
                f.write(f'Receiver: {data}\n')
                print(f'Receiver: {data}')

                # Enter response to Receiver and send to Receiver
                data = input("Enter Transmitter response: ").encode('utf-8')
                f.write(f'Transmitter: {data.decode()}\n')
                self.transmitter.sendto(data, addr)


transmitter = Transmitter('localhost', 11111)
transmitter.start()




























'''import socket


class Server:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.server.bind((host, port))

    def receive_send_msg(self):
        while True:
            # Receive msg from client
            data, addr = self.server.recvfrom(1024)
            data = data.decode('utf-8')
            print(f'Client : {data}')

            # Enter Response and send to client
            data = input("Enter Response : ").encode('utf-8')
            self.server.sendto(data, addr)


server = Server('localhost', 11111)
server.receive_send_msg()'''

