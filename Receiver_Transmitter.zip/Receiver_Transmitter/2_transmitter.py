import socket
import json
import datetime


class Message:
    def __init__(self, text):
        self.text = text
        self.timestamp = datetime.datetime.now()

    def to_dict(self):
        return {
            "text": self.text,
            "timestamp": str(self.timestamp),
        }


class Transmitter:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def transmit(self, message):
        message_dict = message.to_dict()
        message_json = json.dumps(message_dict)
        self.socket.sendto(message_json.encode(), (self.host, self.port))


transmitter = Transmitter('localhost', 8000)

# Read a message from the user and transmit it
text = input("Enter a message to transmit: ")
message = Message(text)
transmitter.transmit(message)
