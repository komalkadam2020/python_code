import json
import socket
import argparse
import signal
import sys


class Receiver:
    def __init__(self, ip, udp_port):
        self.dest_ip = ip
        self.udp_port = udp_port
        self.sock = None

    def __enter__(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            print("UDP socket created successfully")
        except socket.error as err:
            print("Failed to create socket: %s" % err)
            sys.exit(1)

        self.sock.bind((self.dest_ip, self.udp_port))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.sock.close()

    def receive(self):
        def signal_handler(sig, frame):
            print("Interrupt Occurs...Ending Receiver..")
            self.sock.close()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        while True:
            data, addr = self.sock.recvfrom(1024)
            message = data.decode()
            if message == 'ping':
                self.sock.sendto(b'Hi', addr)
            elif message == 'exit':
                self.sock.sendto(b'ok', addr)
                break
            else:
                message = json.loads(data.decode())
                print(f"Received message: {message['message_id']}: {message['text']}  time: {message['time']}")
                response = 'ok'
                self.sock.sendto(response.encode(), addr)


'''if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=9999, help='UDP port number')
    args = parser.parse_args()

    with Receiver('localhost', args.port) as receiver:
        receiver.receive()
'''








'''import json
import socket
import argparse
import signal
import sys


class Receiver:
    def __init__(self, ip, udp_port):
        self.dest_ip = ip
        self.udp_port = udp_port
        self.sock = None

    def __enter__(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            print("UDP socket created successfully")
        except socket.error as err:
            print("Failed to create socket: %s" % err)
            sys.exit(1)

        self.sock.bind((self.dest_ip, self.udp_port))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.sock.close()

    def receive(self):
        def signal_handler(sig, frame):
            print("Interrupt Occurs...Ending Receiver..")
            self.sock.close()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        while True:
            data, addr = self.sock.recvfrom(1024)
            message = data.decode()
            if message == 'ping':
                self.sock.sendto(b'Hi', addr)
            elif message == 'exit':
                self.sock.sendto(b'ok', addr)
                break
            else:
                message = json.loads(data.decode())
                print(f"Received message: {message['message_id']}: {message['text']}  time: {message['time']}")
                response = 'ok'
                self.sock.sendto(response.encode(), addr)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=9999, help='UDP port number')
    args = parser.parse_args()

    with Receiver('localhost', args.port) as receiver:
        receiver.receive()
'''