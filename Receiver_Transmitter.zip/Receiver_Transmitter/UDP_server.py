import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # For UDP

udp_host = 'localhost'                   #socket.gethostname()  # Host IP
udp_port = 12345  # specified port to connect

sock.bind((udp_host, udp_port))

while True:
    print("Waiting for client...")
    data, addr = sock.recvfrom(1024)  # receive data from client
    print("Received Messages:", data, " from", addr)















'''import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 12345))

while True:
    data, addr = server_socket.recvfrom(4096)
    print(str(data))
    message = bytes('Hello, I am UDP server').decode('utf-8')
    server_socket.sendto(message.addr)
'''
