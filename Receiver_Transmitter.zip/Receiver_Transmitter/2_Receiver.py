import json
import socket
import datetime
class Message:
    def __init__(self, text):
        self.text = text
        self.timestamp = datetime.datetime.now()


class Receiver:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.host, self.port))

    def receive(self):
        data, address = self.socket.recvfrom(1024)
        message_dict = json.loads(data.decode())
        message_text = message_dict["text"]
        message_timestamp = datetime.datetime.fromisoformat(message_dict["timestamp"])
        message = Message(message_text)
        message.timestamp = message_timestamp
        return message


receiver = Receiver('localhost', 8000)

# Wait for a message to be received and print it
received_message = receiver.receive()
print(f"Received message: {received_message.text} ({received_message.timestamp})")
