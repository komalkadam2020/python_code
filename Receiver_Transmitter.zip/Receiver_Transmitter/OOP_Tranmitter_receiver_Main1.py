from OOP_Tranmitter1 import Transmitter
from OOP_Receiver1 import Receiver


receiver = Receiver('localhost', 9999)

transmitter = Transmitter('messages.json', 'localhost', 9999)
transmitter.transmit()
while True:
    receiver.receive()

