import socket


class Message:
    def __init__(self, message_id, text, time):
        self.message_id = message_id
        self.text = text
        self.time = time

    @classmethod
    def from_string(cls, string):
        message_id, text, time = string.split()
        return cls(message_id, text, time)

    def to_string(self):
        return f"{self.message_id}|{self.text}|{self.time}"


class Transmitter:
    def __init__(self, filename, ip_address, port):
        self.filename = filename
        self.ip_address = ip_address
        self.port = port

    def transmit_messages(self):
        with open(self.filename, 'r') as f:
            messages = f.readlines()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        for message in messages:
            message_obj = Message.from_string(message.strip())
            sock.sendto(message_obj.to_string().encode(), (self.ip_address, self.port))
            print(f"Message with ID {message_obj.message_id} sent successfully.")
        sock.close()


obj = Transmitter('messages.txt', 'localhost', 12323)
obj.transmit_messages()
