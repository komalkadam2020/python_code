import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)      # For UDP

udp_host = 'localhost'               #socket.gethostname()		# Host IP
udp_port = 12345			        # specified port to connect

msg = "Hello Server..I am client!"
print("UDP target IP:", udp_host)
print("UDP target Port:", udp_port)

sock.sendto(bytes(msg, 'utf-8'), (udp_host, udp_port))	 # Sending message to UDP server









'''import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

msg = bytes("Hello UDP server")
client_socket.sendto(msg, ('localhost', 12345))
data, addr = client_socket.recvfrom(4096)[0].decode('utf-8')
print('Server says')
print(str(data))
client_socket.close()'''
