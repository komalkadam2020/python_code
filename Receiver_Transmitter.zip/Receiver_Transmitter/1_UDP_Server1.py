import socket

host = 'localhost'
port = 11111

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

server.bind((host, port))

while True:
    # Received message from Client
    data, addr = server.recvfrom(1024)
    data = data.decode('utf-8')
    print(f'Client: {data}')

    # Enter response to Client and sent to client
    data = input("Enter server response: ").encode('utf-8')
    server.sendto(data, addr)
