import socket


class Message:
    def __init__(self, message_id, text, time):
        self.message_id = message_id
        self.text = text
        self.time = time

    @classmethod
    def from_string(cls, string):
        message_id, text, time = string.split('|')
        return cls(message_id, text, time)

    def to_string(self):
        return f"{self.message_id}|{self.text}|{self.time}"


class Receiver:
    def __init__(self, ip_address, port):
        self.ip_address = ip_address
        self.port = port

    def receive_messages(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind((self.ip_address, self.port))
        while True:
            data, addr = sock.recvfrom(1024)
            message = Message.from_string(data.decode())
            print(f"Message received from {addr}: {message.to_string()}")
        sock.close()


obj1 = Receiver('localhost', 12323)
obj1.receive_messages()


