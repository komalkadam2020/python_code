class Employee:

    def message(self):
        print('This is  message from Employee')

class Department(Employee):

    def message(self):
        print('This department is inherited from Employee')

emp = Employee()
emp.message()

print('-----------------------------------------------')
dept = Department()
dept.message()