class Employee:
    def add(self, a, b):
        print('The sum of Two numbers: ', a+b)

class Department(Employee):
    def add(self, a, b, c):
        print(' The sum of three numbers : ', a+b+c)

emp = Employee()
emp.add(10, 20)
print('------------------------------------')
dept = Department()
dept.add(50, 20, 30)